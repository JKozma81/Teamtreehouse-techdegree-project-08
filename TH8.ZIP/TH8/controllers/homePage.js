// const db = require('../models');
const Books = require('../models/books');

const state = {
	menuTitle: '',
	bookData: {},
	isTitleMissing: false,
	isAuthorMissing: false,
	paginationLinks: 1
}

// Render the core content for the home page
exports.getHomePageContent = (req, res, next) => {
	res.render('index');
};

// Render the core layout for the home page
exports.getHomePageLayout = (req, res, next) => {
	Books.findAll().then((books) => {
		state.bookData = books;
		state.menuTitle = 'Books';
		res.locals.data = state;
		res.render('layout');
	}).catch((err) => {
		console.error(err)
	});
};

// Render the core layout for the new book page
exports.getNewBookPage = (req, res, next) => {
	state.menuTitle = 'New Book';
	state.errorData = [];
	state.bookData = {};
	isTitleMissing = false;
	isAuthorMissing = false;
	res.locals.data = state;
	res.render('new-book');
};


// Render the core layout for the book details page
exports.getDetailsPage = (req, res, next) => {
	Books.findByPk(parseInt(req.params.bookId, 10)).then((book) => {
		state.menuTitle = 'Update Book';
		state.bookData = book;
		res.locals.data = state;
		res.render('new-book');
	}).catch((err) => {
		console.error(err)
	})
};

// Adding new book to the database
exports.addNewBook = (req, res, next) => {
	const title = req.body.title,
				author = req.body.author,
				genre = req.body.genre,
				year = isNaN(parseInt(req.body.year, 10)) ? null : parseInt(req.body.year, 10);
	Books.create({
		title: title,
		author: author,
		genre: genre,
		year:year
	}).then(() => {
		res.redirect('/books');
	}).catch((err) => {
		// state.menuTitle = 'New Book';
		// state.bookData = {
		// 	title: title,
		// 	author: author,
		// 	genre: genre,
		// 	year: year
		// };

		// console.log(err)
		// console.log(err.type)
		// console.log(err.path)
		// state.isAuthorMissing = err.message === 'Author is required!' ? true : false;
		// state.isTitleMissing = err.message === 'Title is required!' ? true : false;
		// res.locals.data = state;
		console.error(err.message)
		// res.render('new-book');
	});

	// Books.findByPk(parseInt(req.params.bookId)).then((book) => {
	// 	state.menuTitle = book.title;
	// 	state.bookData = book;
	// 	res.locals.data = state;
	// 	res.render('new-book');
	// }).catch((err) => {
	// 	console.error(err)
	// });
};

// Manage book data changes
exports.modifyBook = (req, res, next) => {
	const updatedBookTitle = req.body.title,
				updatedBookAuthor = req.body.author,
				updatedBookGenre = req.body.genre,
				updatedBookYear = isNaN(parseInt(req.body.year, 10)) ? null : parseInt(req.body.year, 10);

	Books.findByPk(parseInt(req.params.bookId, 10)).then((book) => {
		book.title = updatedBookTitle;
		book.author = updatedBookAuthor;
		book.genre = updatedBookGenre;
		book.year = updatedBookYear;
		return book.save()
	}).then(() => {
		res.redirect('/books');
	}).catch((err) => {
		console.error(err)
	});
};

// Deleting book from the database
exports.deletingBook = (req, res, next) => {
	console.log(req.params.bookId)
	Books.findByPk(parseInt(req.params.bookId, 10)).then((book) => {
		return book.destroy();
	}).then(() => {
		res.redirect('/books');
	}).catch((err) => {
		console.error(err)
	});
};