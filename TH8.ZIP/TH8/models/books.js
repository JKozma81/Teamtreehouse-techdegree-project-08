const Sequelize = require('sequelize');
const dataConnection = require('../util/databaseConnection');

const Books = dataConnection.define('Book', {
	id: {
		type: Sequelize.INTEGER,
		autoIncrement: true,
		allowNull: false,
		primaryKey: true
	},
	title: {
		type: Sequelize.STRING,
		allowNull: false,
		validate: {
			notEmpty: {
				msg: "Title is required!"
			}
		}
	},
	author: {
		type: Sequelize.STRING,
		allowNull: false,
		validate: {
			notEmpty: {
				msg: "Author is required!"
			}
		}
	},
	genre: {
		type: Sequelize.STRING,
		// allowNull: false
	},
	year: {
		type: Sequelize.INTEGER,
		// allowNull: false
	},
	createdAt: false
});

module.exports = Books;
