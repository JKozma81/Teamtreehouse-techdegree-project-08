const path = require('path');

exports = path.dirname(process.mainModule.filename);
