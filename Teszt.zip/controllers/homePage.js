// const db = require('../models');
const Books = require('../models/books');

// Render the core content for the home page
exports.getHomePageContent = (req, res, next) => {
	res.render('index');
};

// Render the core layout for the home page
// exports.getHomePageLayout = (req, res, next) => {
// 	db.Book
// 		.findAll({
// 			attributes: [ 'id', 'title', 'author', 'genre', 'year' ]
// 		})
// 		.then((data) => {
// 			data.forEach((element) => {
// 				console.log(element);
// 			});

// 			// console.log('Database', [ ...data ]);
// 			res.locals.menu = { title: 'Books' };
// 			res.render('layout');
// 		});
// };
exports.getHomePageLayout = (req, res, next) => {
	Books.findAll().then((books) => {
		console.log('Data:', books[0]);
		books.forEach((book) => console.log(book.title));
		// console.log('Database', [ ...data ]);
		res.locals.menu = { title: 'Books' };
		res.render('layout');
	});
};
