const Sequelize = require('sequelize');
const dataConnection = require('../util/databaseConnection');

const Books = dataConnection.define('book', {
	id: {
		type: Sequelize.INTEGER,
		autoIncrement: true,
		allowNull: false,
		primaryKey: true
	},
	title: {
		type: Sequelize.STRING,
		allowNull: false,
		validate: {
			notEmpty: {
				msg: "Author can't be blank"
			}
		}
	},
	author: {
		type: Sequelize.STRING,
		allowNull: false,
		validate: {
			notEmpty: {
				msg: "Author can't be blank"
			}
		}
	},
	genre: {
		type: Sequelize.STRING,
		allowNull: false
	},
	year: {
		type: Sequelize.INTEGER,
		allowNull: false
	},
	createdAt: false
});

module.exports = Books;
